#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1, num2, num3;

    printf("Digite o primeiro numero ");
    scanf("%d", &num1);
    printf("Digite o segundo numero ");
    scanf("%d", &num2);
    printf("Digite o terceiro numero ");
    scanf("%d", &num3);

    if(num1 > num2 && num1 > num3)
    {
        printf("o primeiro numero digitado eh o maior");
    }
    else if (num2 > num1 && num2 > num3)
    {
        printf("o segundo numero digitado eh o maior");
    }
    else
    {
        printf("o terceiro numero digitado eh o maior");
    }

    return 0;
}
